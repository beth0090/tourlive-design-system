# TourLive Design System — AI 참고 가이드
> 이 파일은 전역 원칙만 담습니다. 컴포넌트 상세 규칙은 `tourlive_dg_components/*.md`를 첨부하세요.
> 모든 수치·색상은 `tourlive_dg_tokens.json`이 우선합니다.
> **version: 1.1 / last_updated: 2026-05-19**

---

## 🔒 tourlive_dg_tokens.json 보호 원칙 (최우선 — 모든 규칙보다 위)

```
tourlive_dg_tokens.json은 AI가 절대 수정할 수 없는 읽기 전용 파일입니다.

AI는 tourlive_dg_tokens.json을:
  ✅ 읽을 수 있다
  ✅ 참조할 수 있다
  ❌ 수정할 수 없다
  ❌ 반환(출력)할 수 없다
  ❌ 새 값을 추가할 수 없다
  ❌ 버전·날짜를 바꿀 수 없다

tourlive_dg_tokens.json 수정은 사람(디자이너)만 할 수 있습니다.
```

### AI가 tourlive_dg_tokens.json을 건드리려는 신호 (사용자가 즉시 거부할 것)

```
- "tourlive_dg_tokens.json을 업데이트했습니다" 라고 말할 때
- tourlive_dg_tokens.json 파일 내용을 출력할 때
- "_readme.version" 또는 "last_updated"를 변경할 때
- 새로운 color/spacing/component 값을 tourlive_dg_tokens.json에 추가할 때
```

---

## ★ 구현 전 필수 게이트 (코드 작성 전 자동 실행)

아래 3개 질문에 모두 yes여야 구현을 시작합니다.
**하나라도 no면 멈추고 사용자에게 먼저 확인합니다.**

```
① tourlive_dg_tokens.json에 정의된 색상·간격·타이포만 사용하는가?
② components에 정의된 variant만 사용하는가?
③ page_patterns에 정의된 레이아웃 구조를 따르는가?
```

### ⚠️ tourlive_dg_tokens.json 값 사용 원칙 (구현 중 항상 적용)

```
모든 색상·간격·타이포·radius·shadow 값은 반드시 tourlive_dg_tokens.json에서 찾아 사용한다.

❌ 금지: tourlive_dg_tokens.json에 없는 값을 학습 지식·추정·근사로 채우는 것
❌ 금지: tourlive_dg_tokens.json 없이 구현을 시작하는 것
❌ 금지: "{Orange.500}" 같은 참조값을 임의로 해석해 다른 hex를 사용하는 것

✅ 필수: 값이 tourlive_dg_tokens.json에 실제로 존재하는지 확인 후 사용
✅ 필수: tourlive_dg_tokens.json에 없는 값이 필요한 경우 → 즉시 구현 중단 후 사용자에게 아래 형식으로 확인
```

### no일 때 / tourlive_dg_tokens.json에 값이 없을 때 확인 메시지 형식

```
요청하신 [항목]은 현재 디자인 시스템(tourlive_dg_tokens.json)에 정의되지 않았습니다.
구현을 진행하려면 아래 중 하나를 선택해 주세요.

A) 근사값 대체 → 가장 가까운 기존 토큰으로 구현 후 tourlive_dg_history.md에 기록
B) 취소 → 사용자가 직접 tourlive_dg_tokens.json 수정 후 재요청

※ AI는 tourlive_dg_tokens.json을 직접 수정하지 않습니다.
※ 사용자 확인 없이 임의로 A를 선택하지 않습니다.
```

---

## 브랜드 컨텍스트

투어라이브는 가이드 없이 혼자 즐기는 오디오/비디오 셀프투어 서비스입니다.
- 여행지 사진과 콘텐츠가 주인공 — UI는 방해하지 않는다
- 모바일 앱 중심 — 모든 화면은 375px 기준으로 설계
- 단순하고 명확하게 — 정보 위계가 곧 디자인

---

## 전역 구현 규칙

```
[색상]
- tourlive_dg_tokens.json color 값만 사용. 임의 hex 추가 금지
- 브랜드 오렌지(#FF730D)는 CTA·핵심 강조에만
- 그라디언트 남용 금지
- border/subtle 삭제됨 → border/default (#D1D1D1) 사용

[타이포그래피]
- 폰트: Pretendard Variable 단독 사용
- 크기·굵기: tourlive_dg_tokens.json typography.scale 값만
- 한국어 행간 최소 1.5 / 제목 자간 -0.01~-0.02em

[간격]
- tourlive_dg_tokens.json spacing 토큰(xs/sm/md/lg/xl/2xl/3xl/4xl)만 사용
- 각 토큰은 _primitive.Base를 참조 (4px 단위 체계)
- 임의 수치 금지 (예: 7px, 11px, 13px)

[컴포넌트]
- tourlive_dg_tokens.json components에 정의된 variant만 사용
- hover/focus 상태 반드시 구현
- 새 스타일 임의 추가 금지
- 스펙에 명시되지 않은 시각 요소(background, border, shadow, radius 등) 추가 금지
  → 스펙에 없으면 없는 것. "자연스러워 보이게" 보완하지 말 것
- 상세 규칙은 components/*.md 참조

[모바일]
- 기준: 375px
- 터치 영역 최소 44×44px
- 페이지 상태(로딩 / 빈상태 / 에러 / 오프라인)는 기획에 따라 선택 구현 (→ state.md 참조)
- 상태 구현 시 디자인 기본값은 state.md를 따른다
```

---

## 컴포넌트 선택 기준

```
[버튼]
결제·구매·핵심 CTA      → Button.filled (모바일 full width)
취소·보조 액션           → Button.outlined
브랜드 강조 보조         → Button.linepoint
텍스트 링크 수준         → Button.text
삭제·되돌릴 수 없는 액션 → Button.filled (feedback/error 색상)
Player 화면 액션 버튼    → Button.ghost (Player 전용)

[탭]
콘텐츠 전환 탭           → Tab.underline (가로 스크롤)
필터·카테고리 선택       → Tab.fill (칩 나열, 가로 스크롤)
Player 뷰 전환           → SegmentedControl (Player 전용, 균등 분할)

[입력/선택]
선택지 3개 이상          → Dropdown
선택지 2개 이하          → RadioButton
복수 선택                → Checkbox

[뱃지]
인라인 텍스트 표기        → Badge.text
필터 칩, 선택 상태        → Badge.outlined
강조 라벨, 상태 태그      → Badge.filled
※ Badge는 클릭 불가. 버튼 대신 사용 금지

[리스트]
검색 결과, 투어 목록      → List.default (썸네일 108px 왼쪽)
구매한 투어 목록          → List.purchased (썸네일 96px 오른쪽, 상태 7종)
※ 세로형은 커스텀 — 스펙 미정의, 임의 구현 금지

[로딩]
List.default 로딩         → Skeleton.list_default
List.purchased 로딩       → Skeleton.list_purchased
※ List 외 컴포넌트에 Skeleton 적용 금지

[오버레이]
중요 확인·선택 액션      → BottomSheet
단순 피드백·알림         → Toast
필수 확인·경고           → Modal

[구분선]
일반 콘텐츠 사이          → Divider.default (1px)
큰 섹션 구분              → Divider.thick (8px)

[가격 표시]
할인 있음: 원가(취소선, 회색) + "할인가" + 할인가(굵고 크게)
할인 없음: 가격(굵게)
규칙: 콤마 필수, 단위 "원" 숫자 뒤 → 39,000원
```

---

## 페이지 레이아웃 패턴

```
[홈]
topbar → hero_search → city_tab_grid → top_tours → sample_video → bottom_tab

[목록/검색]
topbar → filter_tabbar → list_default → load_more → bottom_tab

[투어 상세]
media_carousel → breadcrumb → title + badges → price_block
→ Divider.thick → TabBar(목차/후기/크리에이터/이용안내) → tab_content
→ StickyBottomCTA (가격 왼쪽 + 구매하기 버튼 오른쪽)

[마이페이지]
topbar → profile_summary → Divider.thick → list_purchased → settings → bottom_tab

[Player]
topbar_player → media_carousel → content_block → action_buttons_ghost
→ audio_player → segmented_control
```

---

## 파일 구성 및 첨부 방법

```
항상 첨부:
  tourlive_dg_tokens.json      ← 모든 값의 소스 (읽기 전용)
  tourlive_dg_guide.md         ← 전역 원칙 (이 파일)

컴포넌트 작업 시 해당 파일만 추가 첨부:
  tourlive_dg_components/button.md      ← Button
  tourlive_dg_components/modal.md       ← Modal
  tourlive_dg_components/tab.md         ← Tab
  tourlive_dg_components/dropdown.md    ← Dropdown
  tourlive_dg_components/badge.md       ← Badge
  tourlive_dg_components/list.md        ← List / Skeleton
  tourlive_dg_components/bottomsheet.md ← BottomSheet
  tourlive_dg_components/toast.md       ← Toast
  tourlive_dg_components/form.md        ← Input / SearchBar / Toggle / Checkbox / RadioButton
  tourlive_dg_components/navigation.md  ← TopBar / BottomTab / StickyBottomCTA
  tourlive_dg_components/divider.md     ← Divider
  tourlive_dg_components/player.md      ← Player 전용 (MediaCarousel / ContentBlock / AudioPlayer / SegmentedControl 배치)
  tourlive_dg_components/state.md       ← 페이지 상태
```

---

## 파일 수정 절차

### tourlive_dg_tokens.json — 읽기 전용. AI 수정 절대 금지.

```
tourlive_dg_tokens.json에 없는 값이 필요한 경우:
1. AI는 구현을 멈추고 사용자에게 알린다
2. 사용자가 직접 tourlive_dg_tokens.json을 수정한다
3. 수정된 tourlive_dg_tokens.json을 첨부 후 재요청한다
```

### tourlive_dg_guide.md / tourlive_dg_components/*.md — 사용자 명시적 요청 시에만 AI 수정 가능

```
수정 후 이 파일 상단 version, last_updated만 올린다
tourlive_dg_tokens.json version은 절대 건드리지 않는다
tourlive_dg_history.md에 반드시 기록한다
```

### ‼️ tourlive_dg_history.md — AI 자동 기록 (절대 생략 불가)

```
tourlive_dg_history.md 기록은 선택이 아닙니다. 아래 조건 중 하나라도 해당하면
작업 완료 전에 반드시 tourlive_dg_history.md에 기록합니다.
기록 없이 작업을 완료했다고 보고하는 것은 규칙 위반입니다.

기록 조건:
1. tourlive_dg_tokens.json이 변경된 경우
2. tourlive_dg_tokens.json 범위 밖 값을 근사 대체한 경우
3. tourlive_dg_guide.md가 수정·삭제된 경우
4. tourlive_dg_components/*.md 파일이 수정·삭제된 경우

tourlive_dg_history.md가 없으면 새로 생성합니다.
```

```markdown
| 날짜 | 요청자 | 내용 | 처리 방식 | 권장 조치 |
|------|--------|------|-----------|-----------|
| YYYY-MM-DD | 사용자 | [요청] | [처리 내용] | [권장 조치] |
```

### 작업 완료 시 반환 규칙

```
커스텀 발생 시               → 결과물 + tourlive_dg_history.md 기록 완료 명시
커스텀 없을 시               → 결과물만 (변경 없음 명시)
guide.md·components 수정 시  → 결과물 + tourlive_dg_history.md 기록 완료 명시
tourlive_dg_tokens.json      → 절대 반환하지 않음
```

### ⭐ 작업 후 필수 사항

```
모든 작업이 끝난 후 tourlive_dg_history.md 파일이 생성 또는 업데이트된 경우,
아래 노션 페이지에 동일한 내용을 업데이트해주세요.
```

[tourlive_dg_history.md 기록](https://www.notion.so/tourlive_dg_history-md-365b04cb84c280759be6cac1bd86054b?pvs=21)

---

## 구현 후 셀프 체크 (전역)

```
[tourlive_dg_tokens.json 대조 — 최우선 확인]
□ 코드에 사용한 모든 색상 hex가 tourlive_dg_tokens.json._primitive에 실제로 존재하는가?
□ 코드에 사용한 모든 spacing px 값이 tourlive_dg_tokens.json.tokens.spacing 또는 _primitive.Base에 실제로 존재하는가?
□ 코드에 사용한 font-size, font-weight, line-height가 tourlive_dg_tokens.json.tokens.typography.scale에 실제로 존재하는가?
□ 코드에 사용한 radius, shadow 값이 tourlive_dg_tokens.json.tokens.radius / tourlive_dg_tokens.json.tokens.shadow에 실제로 존재하는가?
□ tourlive_dg_tokens.json에 없는 값을 한 곳이라도 사용했다면 → 즉시 작업 중단 후 사용자 확인

[일반 체크]
□ 폰트가 Pretendard인가?
□ 터치 영역이 최소 44×44px인가?
□ 상태 구현이 필요한 경우 state.md 기본값을 따랐는가?
□ 스펙에 없는 background, border, shadow, radius를 임의로 추가하지 않았는가?
□ tourlive_dg_tokens.json을 출력하거나 수정하지 않았는가?
□ guide.md·components.md 수정 또는 커스텀 처리가 있었다면 tourlive_dg_history.md에 기록했는가?
  → 기록하지 않았다면 지금 즉시 기록 후 완료 보고

※ 컴포넌트별 체크리스트는 각 tourlive_dg_components/*.md 참조
```
