# Button 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.Button`
> filled와 보조 버튼을 함께 쓸 때는 outlined를 사용하세요. 같은 variant를 근처에 나란히 배치하지 않습니다.

---

## Variant 선택 기준

| 상황 | Variant |
|------|---------|
| 결제·구매·핵심 CTA | `filled` — 모바일 full width |
| 취소·보조 액션 | `outlined` |
| 브랜드 강조 보조 | `linepoint` |
| 텍스트 링크 수준 | `text` |
| 삭제·되돌릴 수 없는 액션 | `filled` + `feedback/error` 색상 |
| Player 화면 액션 (댓글·스크립트·위치보기) | `ghost` — Player 전용 |

---

## 크기

| Size | Height | Padding | Font |
|------|--------|---------|------|
| sm | 34px | 10px 15px | body_sm (14px) |
| md | 44px | 10px 30px | body (15px) |
| lg | 50px | 15px 30px | body_lg (16px) |
| xl | 68px | 15px 30px | body_lg (16px) / 2줄 지원 |

radius: `8px` (radius/sm) 고정
layout: 버튼 내 콘텐츠 항상 가로·세로 가운데 정렬 (`display: flex / justify-content: center / align-items: center`)

---

## 아이콘

| 항목 | 값 |
|------|----|
| 표시 여부 | `hasIcon: true / false` |
| 위치 | 텍스트 왼쪽 |
| 크기 | sm/md 버튼 → 16px (`icon/sm`) / lg/xl 버튼 → 20px (`icon/md`) |
| 텍스트와 간격 | 4px (`spacing/xs`) |

```
hasIcon: false → 아이콘 영역 자체를 렌더하지 않음 (공백 유지 금지)
hasIcon: true  → 아이콘·텍스트 세로 가운데 정렬 (align-items: center)
버튼 크기별 아이콘 크기 혼용 금지 — sm/md는 16px, lg/xl은 20px으로 고정
```

---

## Variant 스펙

### filled
```
enabled  → bg: #FF730D / text: #FFFFFF
disabled → bg: #D1D1D1 / text: #FFFFFF
pressed  → bg: #FF5811 / text: #FFFFFF
```

### outlined
```
enabled  → bg: #FFFFFF / border: 1px #A0A0A0 / text: #1A1A1A
disabled → bg: #FFFFFF / border: 1px #D1D1D1 / text: #A0A0A0
pressed  → bg: #FF5811 / text: #FFFFFF
```

### linepoint
```
enabled  → bg: #FFFFFF / border: 1px #FF730D / text: #FF730D
disabled → bg: #FFFFFF / border: 1px #D1D1D1 / text: #A0A0A0
pressed  → bg: #FF5811 / text: #FFFFFF
```

### text
```
enabled  → text: #FF730D / underline: true
disabled → text: #A0A0A0
pressed  → text: #FF5811 / underline: true
border, bg 없음
```

### ghost
```
⚠️ Player 화면 전용 — 다른 화면에서 사용 금지
radius: 8px (radius/sm)
enabled  → bg: rgba(255,255,255,0.15) / text: #FFFFFF
pressed  → bg: rgba(255,255,255,0.25) / text: #FFFFFF
disabled → bg: rgba(255,255,255,0.08) / text: #8A8A8A
```

---

## ❌ 절대 하지 말 것

```
- 같은 variant를 근처에 나란히 배치 금지 (예: filled + filled)
- filled와 보조 버튼을 함께 쓸 때는 반드시 outlined 사용
- radius는 모든 variant 8px(radius/sm) 고정 — 예외 없음
- ghost variant를 Player 화면 외에서 사용 금지
- text variant에 bg/border 추가 금지
- disabled 상태 생략 금지
- hover 스타일 추가 금지 — pressed(클릭) 상태만 구현
```

---

## 셀프 체크

```
□ 같은 variant가 근처에 나란히 배치되지 않았는가?
□ filled와 보조 버튼을 함께 쓴다면 outlined를 사용했는가?
□ radius가 8px인가? (ghost 포함 전체 8px — 예외 없음)
□ disabled 상태가 구현되어 있는가?
□ pressed 상태가 구현되어 있는가?
□ 모바일 CTA는 full width인가?
□ text variant에 bg/border가 없는가?
□ ghost variant가 Player 화면에서만 쓰이는가?
```
