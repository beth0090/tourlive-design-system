# BottomSheet 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.BottomSheet`, `tokens.layout.sheet_pc`
> 모바일 전용 (max-width: 701px). 중요 액션·선택지 제공 시 사용. 단순 안내는 Toast.

---

## 스펙

```
bg: #FFFFFF
radius: 16px 16px 0 0 (상단만)
backdrop: rgba(0,0,0,0.50)
animation: 아래→위 슬라이드인 / 250ms cubic-bezier(0.34,1.56,0.64,1) (spring)
dismiss: backdrop 클릭 또는 close_button
handle(드래그바): 없음
max-height: 80vh (초과 시 content_area 내부 스크롤 — 아래 참조)
```

---

## 너비·위치 (layout.sheet_pc 기준)

모바일(701px 이하)과 PC(702px 이상) 모두 동일한 규칙을 따릅니다.

```
width: min(600px, 100%)
position: fixed / bottom: 0 / 수평 중앙 정렬
alignment: left: 50% / transform: translateX(-50%)
```

> 뷰포트가 600px 이하이면 100% 너비로 자동 fallback됩니다.

---

## close_button

```
위치: content_area 우상단 고정 / 항상 표시
icon: × (24px) / color: #3A3A3A
touch_target: 44x44px
```

---

## content_area

```
padding: 20px 24px 0
```

### 요소 조합 규칙

- **title**: 필수
- **sub_title / body / sub_text**: 선택. 필요한 요소만 조합해서 사용

| 요소 | 스펙 | 필수 여부 |
|------|------|-----------|
| title | 20px / weight 600 / #1A1A1A | ✅ 필수 |
| sub_title | 18px / weight 600 / #1A1A1A / margin-top 15px | 선택 |
| body | 16px / weight 400 / #3A3A3A / margin-top 15px | 선택 |
| sub_text | 16px / weight 400 / #8A8A8A / margin-top 15px | 선택 |

### 높이 및 스크롤 처리

시트 자체는 콘텐츠 높이에 따라 자연스럽게 늘어나되, `max-height: 80vh`를 초과할 수 없습니다.

```
시트 구조 (80vh 초과 시):
  ┌─────────────────────────────┐  ← 상단 고정 (close_button 포함 header)
  │  content_area               │  ← overflow-y: auto / 스크롤 영역
  │  (스크롤)                   │
  └─────────────────────────────┘  ← 하단 고정 (button_area)
```

- **header 영역** (close_button + title): 고정, 스크롤 제외
- **content_area 내 sub_title·body·sub_text**: 스크롤 대상
- **button_area**: 고정, 스크롤 제외

---

## button_area

```
padding: 20px 24px
safe_area: padding-bottom env(safe-area-inset-bottom) — 생략 금지
```

| Layout | 구성 |
|--------|------|
| single | Button.filled / full width |
| double | 왼쪽 Button.outlined flex 1 / 오른쪽 Button.filled flex 2 / gap 10px |

---

## ❌ 절대 하지 말 것

```
- 702px 이상 화면에서 width: 100% 고정 사용 금지 — min(600px, 100%) 적용
- 하단에 radius 부여 금지 — 상단(16px)만
- button_area safe-area 생략 금지
- 버튼 3개 이상 금지
- handle(드래그바) 사용 금지
- max-height: 80vh 초과 금지
- 80vh 초과 시 시트 전체 스크롤 금지 — content_area만 스크롤
- title 생략 금지 — 항상 필수
```

---

## 셀프 체크

```
□ 상단 radius가 16px 16px 0 0인가?
□ 아래→위 슬라이드인 애니메이션이 적용되었는가?
□ width가 min(600px, 100%)이며 수평 중앙 정렬인가?
□ max-height가 80vh로 제한되어 있는가?
□ 80vh 초과 시 content_area만 스크롤되는가?
□ header와 button_area는 고정되어 있는가?
□ title이 반드시 포함되어 있는가?
□ close_button이 우상단에 있는가?
□ backdrop 클릭으로 닫히는가?
□ button_area에 safe-area가 적용되었는가?
□ handle(드래그바)이 없는가?
