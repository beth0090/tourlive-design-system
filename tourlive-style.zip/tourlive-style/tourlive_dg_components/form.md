# Form 컴포넌트 (Input / SearchBar / Toggle / Checkbox / RadioButton)
> 참조: `tourlive_dg_tokens.json` → `components.Input`, `SearchBar`, `Toggle`, `Checkbox`, `RadioButton`

---

## 컴포넌트 선택 기준

| 상황 | 컴포넌트 |
|------|---------|
| 일반 텍스트 입력 | `Input` |
| 검색 전용 입력 | `SearchBar` |
| 선택지 2개 이하 단일 선택 | `RadioButton` |
| 복수 선택 | `Checkbox` |
| on/off 전환 | `Toggle` |

---

## Input

```
height: 48px
radius: 8px (radius/sm)
padding: 0 15px
```

| 상태 | border | text | 기타 |
|------|--------|------|------|
| default | 1px #D1D1D1 | placeholder #A0A0A0 | |
| typing | 1.5px #FF730D | #1A1A1A | label #FF730D / 삭제(x) 아이콘 |
| filled | 1px #D1D1D1 | #1A1A1A | 삭제(x) 아이콘 |
| error | 1.5px #FA3E4D | #1A1A1A | label #FA3E4D |
| disabled | 1px #D1D1D1 | #A0A0A0 | bg #F2F4F7 |

label 색상: default #8A8A8A / typing #FF730D / error #FA3E4D

---

## SearchBar

```
height: 48px
bg: #F9F9F9
radius: 9999px (radius/full)
border: none
left: 검색 아이콘 (#8A8A8A)
right: 삭제(x) 아이콘 (텍스트 입력 시 표시)
placeholder: #A0A0A0
```

| 상태 | bg |
|------|-----|
| default | #F9F9F9 |
| focus | #F9F9F9 + shadow |
| filled | #F9F9F9 + delete_icon 표시 |

---

## RadioButton

```
size: sm 18px / lg 24px
```

| 상태 | border | 기타 |
|------|--------|------|
| default | 2px #D1D1D1 | bg transparent |
| selected | 2px #FF730D | dot #FF730D |
| disabled | 2px #D1D1D1 | bg #F2F4F7 |

---

## Checkbox

```
radius: 4px
size: sm 18px / lg 24px
icon: sm 10px / lg 14px
```

| 상태 | border | bg | icon |
|------|--------|-----|------|
| default | 2px #D1D1D1 | transparent | - |
| selected | 2px #FF730D | #FF730D | #FFFFFF |
| disabled | 2px #D1D1D1 | #F2F4F7 | - |

---

## Toggle

```
track: 44x24px / radius 9999px
handle: 20x20px / radius 9999px
```

| 상태 | track | handle |
|------|-------|--------|
| on | #FF730D | #FFFFFF |
| off | #D1D1D1 | #FFFFFF |
| disabled | #F2F4F7 / opacity 0.4 | #FFFFFF |

---

## 셀프 체크

```
□ Input 상태별 border 색상이 올바른가?
□ Input disabled bg가 #F2F4F7인가?
□ SearchBar border가 없는가? (radius/full)
□ RadioButton selected dot이 #FF730D인가?
□ Checkbox selected bg가 #FF730D인가?
□ Toggle track on이 #FF730D인가?
□ 모든 요소 터치 영역이 44px 이상인가?
□ disabled 상태가 구현되었는가?
```
