# TourLive — Page State
> 기획에서 정의한 내용이 있으면 그것을 따릅니다.
> 기획에 없는 경우 아래 기본값을 적용합니다.
> **version: 1.0 / last_updated: 2026-05-19**

---

## 상태 종류

```
로딩중   → 데이터를 불러오는 중
빈 상태  → 콘텐츠가 없음
에러     → 네트워크는 있으나 서버/데이터 문제
오프라인 → 네트워크 자체가 없음
```

---

## 로딩중 (Loading)

```
화면 전체 dim   → color/overlay (rgba(0,0,0,0.50))
스피너          → 52×52px / color/text/inverse (#FFFFFF)
텍스트          → color/text/inverse (#FFFFFF) / typography/body (15px) / 생략 가능
```

List 로딩은 Skeleton 사용 (→ list.md 참조)

---

## 빈 상태 / 에러 / 오프라인 공통 구조

```
[아이콘]      → 원형 테두리 + ! / 52×52px / outline 스타일 / color/text/disabled (#A0A0A0)
[타이틀]      → typography/h3 (20px, weight 600) / color/text/strong (#1A1A1A)
[서브텍스트]  → typography/body (15px, weight 400) / color/text/subtle (#8A8A8A) / 생략 가능
[버튼]        → Button.outlined (기본) / Button.filled (기획에서 핵심 액션으로 정의한 경우)
              버튼 2개일 때: 세로 배치 / full width / gap 8px / 같은 variant 사용 금지
```

### 정렬·간격
```
정렬     : 수직·수평 center
위치     : 페이지 상하 중앙
아이콘 ↓ : spacing/xl (20px)
타이틀 ↓ : spacing/sm (8px)
서브   ↓ : spacing/xl (20px)
```

---

## 구현 후 셀프 체크

```
□ 로딩에 dim + 스피너를 사용했는가? (List는 Skeleton)
□ 빈상태·에러·오프라인 아이콘이 52×52px 원형 테두리 + ! 인가?
□ 버튼이 outlined 또는 filled인가?
□ 기획에 없는 상태도 구현했는가?
```
