# Navigation 컴포넌트 (TopBar / BottomTab / StickyBottomCTA)
> 참조: `tourlive_dg_tokens.json` → `components.TopBar`, `BottomTab`, `StickyBottomCTA`

---

## TopBar

모든 페이지 상단 고정 네비게이션.

```
height: 56px (고정)
bg: #FFFFFF
padding: 0 20px
border_bottom: 페이지 성격에 따라 선택 (1px solid #E1E1E1 또는 없음)
```

| 슬롯 | 스펙 |
|------|------|
| left | 최대 2개 아이콘 (뒤로가기·홈 등) |
| center | title: 18px / weight 600 / #1A1A1A / 항상 center |
| right | 최대 2개 아이콘 (검색·닫기 등) |

아이콘: 24px / #1A1A1A / touch_target 44x44px / 아이콘 간 gap 8px (spacing/sm)

### 타이틀 항상 정중앙 유지

좌우 슬롯의 아이콘 개수가 다를 때 타이틀이 한쪽으로 치우치는 현상을 방지합니다.

```
구현 방법: 좌우 슬롯 모두 동일한 고정 너비(width: 120px)를 부여.
           아이콘 최대 2개 기준 — 44px + 44px + gap 8px = 96px.
           title은 flex: 1 / text-align: center 유지 — normal flow 안에서 항상 정중앙.
```

> position: absolute 방식은 title이 document flow에서 벗어나 내용 크기가 레이아웃에 반영되지 않으므로 사용하지 않습니다.

### TopBar — Player 변형
> ⚠️ Player 화면 전용. 구조는 기본 TopBar와 동일하고 색상만 교체.

```
height: 56px (동일)
bg: #000000 (color/player/background/page)
border_bottom: 없음
```

| 슬롯 | 스펙 |
|------|------|
| left | 아이콘: #FFFFFF (color/player/icon/default) |
| center | title: 18px / weight 600 / #FFFFFF (color/player/text/strong) / center |
| right | 아이콘: #FFFFFF (color/player/icon/default) |

### ❌ 절대 하지 말 것
```
- bg 색상 변경 금지 — 기본은 항상 #FFFFFF / Player 변형만 #000000
- 아이콘 좌우 슬롯 각각 3개 이상 금지
- title 좌측/우측 정렬 금지 — 항상 center
- height 56px 변경 금지
- Player 변형 색상을 일반 TopBar에 사용 금지
```

---

## BottomTab

앱 최하단 고정 네비게이션. 5개 탭 고정. 모바일 전용(max-width: 701px).

```
height: 60px (고정)
bg: #FFFFFF
border_top: 1px solid #E1E1E1
safe_area: padding-bottom env(safe-area-inset-bottom) — 생략 금지
tabs: 홈 / 검색 / 여행지도 / 나의 콘텐츠 / 프로필
```

아이템:
```
layout: 아이콘(24px) + 텍스트 수직 center
font: 12px / weight 400
gap: 4px (아이콘-텍스트)
touch_target: 44x44px
active: icon #FF730D / text #FF730D
inactive: icon #8A8A8A / text #8A8A8A
```

### ❌ 절대 하지 말 것
```
- 탭 개수 변경 금지 — 5개 고정
- 702px 이상 화면에 사용 금지
- height 60px 변경 금지
- safe-area 생략 금지
```

---

## StickyBottomCTA

페이지 하단 고정 CTA 영역. BottomTab과 함께 사용 금지.

```
bg: #FFFFFF
border_top: 없음
padding: 20px 상하 / 24px 좌우 (spacing/20, spacing/24 — 24px은 커스텀)
safe_area: padding-bottom env(safe-area-inset-bottom) — 생략 금지
position: fixed bottom 0 / z-index 상위
```

| Layout | 구성 |
|--------|------|
| single | Button.filled / full width |
| double | 왼쪽 flex 1 (variant 상황에 따라) / 오른쪽 Button.filled flex 2 / gap 5px |

### ❌ 절대 하지 말 것
```
- BottomTab과 동시 사용 금지
- 버튼 3개 이상 금지
- 상단 border/shadow 추가 금지
- safe-area 생략 금지
- right 버튼을 filled 외 다른 variant로 변경 금지
```

---

## 셀프 체크

```
[TopBar]
□ height가 56px인가?
□ title이 center 정렬인가?
□ 아이콘 슬롯이 좌우 각 2개 이하인가?
□ bg가 #FFFFFF인가? (Player 변형은 #000000)
□ Player 변형: 아이콘/텍스트가 #FFFFFF인가?
□ Player 변형 색상이 일반 화면에서 쓰이지 않는가?

[BottomTab]
□ height가 60px인가?
□ 탭이 5개인가?
□ safe-area가 적용되었는가?
□ active 색상이 #FF730D인가?
□ 702px 이상에서 숨겨지는가?

[StickyBottomCTA]
□ BottomTab과 함께 쓰이지 않는가?
□ safe-area가 적용되었는가?
□ border-top/shadow가 없는가?
□ double layout에서 right가 Button.filled인가?
```
