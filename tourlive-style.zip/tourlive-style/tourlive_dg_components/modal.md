# Modal 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.Modal`
> 중요한 확인·알림에만 사용. 단순 안내는 Toast를 사용하세요.

---

## 구조 다이어그램

```
┌─────────────────────────────────┐  ← border-radius: 20px / overflow: hidden
│                                 │  ← container padding: 없음
│   title only title only         │  ┐
│   title only title only         │  │ content_area padding: 28px 24px 24px
│   title only                    │  ┘ font: 20px / weight 600 / center
│                                 │
│  [   left btn   ][  right btn  ]│  ← height: 56px / border 없음
│  bg: #F2F4F7     bg: #FF730D   │
│  color: #1A1A1A  color: #FFF   │
│  w400            w700           │
└─────────────────────────────────┘
   radius: 0 0 0 20px  radius: 0 0 20px 0
```

---

## 핵심 스펙

| 항목 | 값 |
|------|-----|
| 모달 radius | `20px` (radius/xl) |
| 모달 overflow | `hidden` 필수 |
| 모달 padding | **없음** |
| 모달 width | `335px` |
| backdrop | `rgba(0,0,0,0.50)` |
| 콘텐츠 padding | `28px 24px 24px` (content_area에만) |
| 콘텐츠 font | `20px / weight 600 / center / color #1A1A1A` |
| 버튼 높이 | `56px` |
| 버튼 구분선 | **없음** (수평·수직 모두 금지) |
| 왼쪽 버튼 bg | `#F2F4F7` |
| 왼쪽 버튼 text | `#1A1A1A / weight 400` |
| 왼쪽 버튼 radius | `0 0 0 20px` |
| 오른쪽 버튼 bg | `#FF730D` |
| 오른쪽 버튼 text | `#FFFFFF / weight 700` |
| 오른쪽 버튼 radius | `0 0 20px 0` |
| 등장 애니메이션 | `scale(0.95→1) + opacity(0→1) / 250ms spring` |

---

## React 구현 예시

```jsx
<div style={{
  background: '#FFFFFF',
  borderRadius: '20px',
  width: '335px',
  overflow: 'hidden',
}}>
  <div style={{
    padding: '28px 24px 24px',
    textAlign: 'center',
    fontSize: '20px',
    fontWeight: 600,
    lineHeight: 1.45,
    color: '#1A1A1A',
  }}>
    {title}
  </div>
  <div style={{ display: 'flex', height: '56px' }}>
    <button style={{
      flex: 1, background: '#F2F4F7', border: 'none',
      fontSize: '15px', fontWeight: 400, color: '#1A1A1A',
      borderRadius: '0 0 0 20px', cursor: 'pointer',
    }}>{leftLabel}</button>
    <button style={{
      flex: 1, background: '#FF730D', border: 'none',
      fontSize: '15px', fontWeight: 700, color: '#FFFFFF',
      borderRadius: '0 0 20px 0', cursor: 'pointer',
    }}>{rightLabel}</button>
  </div>
</div>
```

### 버튼 1개일 때

```jsx
<button style={{
  width: '100%', height: '56px',
  background: '#FF730D', border: 'none',
  fontSize: '15px', fontWeight: 700, color: '#FFFFFF',
  borderRadius: '0 0 20px 20px', cursor: 'pointer',
}}>{label}</button>
```

---

## ❌ 절대 하지 말 것

```
- container에 padding 부여 금지
- 버튼에 border/outline 사용 금지 (왼쪽 버튼도 포함)
- 버튼 사이 수직 구분선 금지
- 버튼 영역 위 수평 구분선(border-top) 금지
- 버튼에 pill radius(9999px) 금지
- radius를 16px으로 설정 금지 → 반드시 20px
- 왼쪽 버튼 bg를 transparent/white로 설정 금지 → 반드시 #F2F4F7
```

---

## 셀프 체크

```
□ container에 padding이 없는가?
□ overflow: hidden이 있는가?
□ content_area padding이 28px 24px 24px인가?
□ 모달 radius가 20px인가?
□ 버튼 영역에 border가 전혀 없는가? (수평·수직 모두)
□ 왼쪽 버튼 bg가 #F2F4F7인가?
□ 오른쪽 버튼 bg가 #FF730D인가?
□ 두 버튼 모두 border/outline이 없는가?
□ 왼쪽 버튼 radius가 '0 0 0 20px'인가?
□ 오른쪽 버튼 radius가 '0 0 20px 0'인가?
```
