# Dropdown 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.Dropdown`
> 선택지 3개 이상일 때 사용. 2개 이하는 RadioButton.

---

## 스펙

```
bg: #FFFFFF
border: 1px #D1D1D1
radius: 8px (radius/sm)
shadow: 0px 4px 12px 0px rgba(0,0,0,0.30)
```

---

## 아이템 상태

| 상태 | bg | text |
|------|-----|------|
| default | transparent | #3A3A3A |
| hover | #F9F9F9 | #1A1A1A |
| selected | #F9F9F9 | #FF730D |
| disabled | #F2F4F7 | #A0A0A0 |

---

## 셀프 체크

```
□ 선택지가 3개 이상인 경우에 사용하는가?
□ selected 아이템 text가 #FF730D인가?
□ shadow가 적용되어 있는가?
□ hover 상태가 구현되었는가?
```
