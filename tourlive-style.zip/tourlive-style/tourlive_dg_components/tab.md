# Tab 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.Tab`

---

## Variant 선택 기준

| 상황 | Variant |
|------|---------|
| 카테고리 필터, 국가/지역 탭 (가로 스크롤) | `underline` |
| 2~4개 고정 탭, 균등 분할 | `fill` |
| Player 화면 하단 뷰 전환 | `SegmentedControl` — Player 전용 |

---

## Tab.underline

```
가로 스크롤 허용 (scrollbar hidden)
item padding: 하단 10px / 좌우 15px
```

| 상태 | color | border |
|------|-------|--------|
| active | #1A1A1A | 하단 2px solid #1A1A1A |
| inactive | #A0A0A0 | 없음 |

---

## Tab.fill

```
container: bg #FFFFFF / radius 9999px
균등 분할 (flex)
```

| 상태 | bg | text |
|------|-----|------|
| active | #FF730D | #FFFFFF |
| inactive | transparent | #8A8A8A |

---

---

## SegmentedControl
> ⚠️ Player 화면 전용. 다른 화면에서 사용 금지.

```
⚠️ Player 화면 외 사용 금지
height: 52px (컨테이너)
padding: 4px (컨테이너 내부)
radius: 16px (컨테이너) / 12px (아이템)
layout: 균등 분할 (flex) — 1개 100% / 2개 50%50% / 3개 33%33%33%
position: fixed bottom 0
outer_padding: 12px 상하 / 20px 좌우
safe_area: padding-bottom env(safe-area-inset-bottom) — 생략 금지
```

| 요소 | 값 |
|------|----|
| 컨테이너 bg | #E1E1E1 |
| 활성 bg | #FFFFFF |
| 비활성 bg | transparent |
| 텍스트 (공통) | #000000 |
| 활성 font_weight | 700 |
| 비활성 font_weight | 400 |
| 아이콘 크기 | 18px |
| 아이콘-텍스트 gap | 6px |

### ❌ 절대 하지 말 것
```
- Player 화면 외 사용 금지
- 가로 스크롤 방식 사용 금지 — 반드시 균등 분할
- 선택지 1개일 때 숨김 처리 금지 — 100% 너비로 표시
- 컨테이너 배경 없이 아이템만 나열 금지
- safe-area 생략 금지
```

---

## 셀프 체크

```
□ underline: 가로 스크롤이 구현되었는가?
□ underline: active 하단 border가 있는가?
□ fill: container radius가 9999px인가?
□ fill: active bg가 #FF730D인가?
□ SegmentedControl: Player 화면에서만 쓰이는가?
□ SegmentedControl: 균등 분할(flex)이 적용되었는가?
□ SegmentedControl: safe-area가 적용되었는가?
□ hover/focus 상태가 있는가?
```
