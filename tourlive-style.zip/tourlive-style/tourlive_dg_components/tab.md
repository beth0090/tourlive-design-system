# Tab 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.Tab`

---

## Variant 선택 기준

| 상황 | Variant |
|------|---------|
| 카테고리 필터, 국가/지역 탭 (가로 스크롤) | `underline` |
| 필터 칩 — 개별 chip 나열 (가로 스크롤, 트랙 없음) | `fill` |
| 컨테이너 트랙 + 균등 분할 뷰 전환 (최대 4개) | `SegmentedControl` |

---

## Tab.underline

```
가로 스크롤 허용 (scrollbar hidden)
item padding: 하단 10px / 좌우 15px
```

| 상태 | color | border |
|------|-------|--------|
| active | #1A1A1A | 하단 2px solid #1A1A1A |
| inactive | #A0A0A0 | 없음 |

---

## Tab.fill
> 필터 칩. 개별 pill chip이 독립적으로 나열됩니다.
> 전체를 감싸는 컨테이너 트랙이 없습니다 — 트랙 + 균등 분할이 필요하면 `SegmentedControl`을 사용하세요.

```
layout: 개별 chip 나열 — 컨테이너 트랙 없음, 균등 분할 아님
scroll: 가로 스크롤 허용 (scrollbar hidden)
gap: 8px (chip 간격)
chip height: 38px
chip padding: 좌우 16px
chip radius: 9999px (radius/full)
font: 15px (typography/body)
```

| 상태 | bg | border | text | weight |
|------|-----|--------|------|--------|
| active | #FF730D | 1.5px solid #FF730D | #FFFFFF | 700 |
| inactive | #FFFFFF | 1.5px solid `color/border/default` | #1A1A1A | 400 |
| disabled | — | — | — | opacity 40% + pointer-events: none |

### ❌ 절대 하지 말 것
```
- 전체를 감싸는 회색 컨테이너 트랙(bg: muted) 사용 금지
- chip에 border 없이 배경색만 사용 금지
- inactive chip에 transparent 배경 사용 금지 — 반드시 #FFFFFF
- 균등 분할(flex) 레이아웃 사용 금지 — 각 chip은 내용에 맞게 자동 너비
```

---

## SegmentedControl
> 컨테이너 트랙 + 균등 분할 전용. 개별 chip 나열 형태는 `Tab.fill`을 사용합니다.
> Player 화면에서 쓸 때만 아래 「Player 화면 제약」을 추가로 적용합니다.

### 기본 스펙

```
height: 52px (컨테이너)
padding: 4px (컨테이너 내부)
radius: 16px (컨테이너) / 12px (아이템)
font: 15px (typography/body)
layout: 균등 분할 (flex) — 1개 100% / 2개 50% / 3개 33.3% / 4개 25%
count: 1~4개 — 최대 4개. 5개 이상 생성 금지
label: 4개 배치 시 한글 6자 이내 (아이콘 동반 시 4자 이내)
       └ 375px 실측 기준 — 4개일 때 아이템 80.75px, 한글 15px ≈ 13px/자
min touch target: 44px (52 − padding 8)
icon: 18px / 텍스트 왼쪽 / gap 6px
position: static — 콘텐츠 흐름 내 배치
outer_padding: 없음 — 페이지 좌우 여백을 따름
```

| 요소 | 값 | 참조 토큰 |
|------|----|-----------|
| 컨테이너 bg | #F2F4F7 | `color/background/muted` |
| 활성 bg | #1A1A1A | `color/text/strong` |
| 활성 text | #FFFFFF | `color/text/inverse` |
| 활성 font_weight | 700 | — |
| 비활성 bg | transparent | — |
| 비활성 text | #1A1A1A | `color/text/strong` |
| 비활성 font_weight | 400 | — |

### 상태 제공 범위

```
hover / focus / disabled 상태를 제공하지 않습니다.
→ 별도 스타일을 정의하지 마세요.
→ 단, outline: none으로 브라우저 기본 포커스 링을 제거하지는 마세요.
```

### Player 화면 제약
> Player 화면에서만 아래를 추가 적용. 나머지는 기본 스펙과 동일.
> 배치·동작 규칙은 `player.md` 참조.

```
position: fixed bottom 0
outer_padding: 12px 상하 (spacing/md) / 20px 좌우 (spacing/xl)
safe_area: padding-bottom env(safe-area-inset-bottom) — 생략 금지
팔레트 교체: 일반 color/* 대신 color/player/segment/* 사용
```

| 요소 | 값 | 참조 토큰 |
|------|----|-----------|
| 컨테이너 bg | #E1E1E1 | `color/player/segment/container` |
| 활성 bg | #FFFFFF | `color/player/segment/active_bg` |
| 활성 text | #000000 | `color/player/segment/text` |
| 비활성 text | #000000 | `color/player/segment/text` |

> ⚠️ Player는 활성 표현이 기본과 반대입니다 (기본: 검정 bg + 흰 글씨 / Player: 흰 bg + 검정 글씨).
> `color/player/segment/active_bg`가 tourlive_dg_tokens.json에 #FFFFFF로 고정돼 있어 그대로 따릅니다.
> 통일하려면 tokens.json 수정이 선행돼야 합니다 — `tourlive_dg_history.md` 참조.

### ❌ 절대 하지 말 것
```
- 가로 스크롤 방식 사용 금지 — 반드시 균등 분할
- 선택지 5개 이상 생성 금지 — 최대 4개. 초과가 필요하면 Tab.underline 사용
- 선택지 1개일 때 숨김 처리 금지 — 100% 너비로 표시
- 컨테이너 배경 없이 아이템만 나열 금지
- hover / focus / disabled 스타일 정의 금지
- outline: none으로 브라우저 기본 포커스 링 제거 금지
- Player 화면에서 일반 color/* 팔레트 사용 금지 → color/player/segment/*
- Player 외 화면에서 fixed 배치·safe-area 적용 금지
- Player 화면에서 safe-area 생략 금지
- 활성 아이템에 shadow·border 추가 금지 — 스펙에 없음
- 개별 chip 나열 형태로 변형 금지 → Tab.fill 사용
```

---

## 셀프 체크

```
□ underline: 가로 스크롤이 구현되었는가?
□ underline: active 하단 border가 있는가?
□ fill: chip radius가 9999px, height가 38px인가?
□ fill: 컨테이너 트랙 없이 개별 chip으로 나열되는가?
□ fill: inactive chip 배경이 #FFFFFF이고 border가 있는가?
□ fill: active bg가 #FF730D인가?
□ SegmentedControl: 선택지가 1~4개인가?
□ SegmentedControl: 균등 분할(flex)이 적용되었는가?
□ SegmentedControl: 컨테이너 트랙 배경이 있는가?
□ SegmentedControl: 활성 아이템이 검정 bg(#1A1A1A) + 흰 글씨(#FFFFFF)인가? (Player 제외)
□ SegmentedControl: hover/focus/disabled 스타일을 추가하지 않았는가?
□ SegmentedControl: outline을 제거하지 않았는가?
□ SegmentedControl(Player): player 팔레트 + 하단 고정 + safe-area가 적용되었는가?
□ SegmentedControl(Player 외): fixed·safe-area를 적용하지 않았는가?
□ Tab: hover/focus 상태가 있는가? (SegmentedControl은 제외 — 상태 미제공)
```
