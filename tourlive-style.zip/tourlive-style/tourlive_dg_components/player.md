# Player 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.SegmentedControl`, `color.player.*`
> Player 화면은 전용 컬러 팔레트(`color.player.*`)를 사용합니다. 일반 색상 토큰 사용 금지.

---

## Player 화면 컬러 원칙

```
배경              color/player/background/page  (#000000)
주요 텍스트       color/player/text/strong      (#FFFFFF)
보조 텍스트       color/player/text/subtle      (#8A8A8A)
기본 아이콘       color/player/icon/default     (#FFFFFF)
보조 아이콘       color/player/icon/subtle      (#8A8A8A)
재생버튼 배경     color/player/control/play_bg  (#FFFFFF)
재생버튼 아이콘   color/player/control/play_icon (#000000)
```

---

## TopBar — Player 예외 규칙

> navigation.md의 TopBar Player 변형을 따르되, 아래 항목은 Player 화면 전용 예외 적용.

```
icon_btn_background: none (transparent) — 브라우저 기본 배경 제거 필수
icon_btn_border:     none               — 브라우저 기본 테두리 제거 필수
```

검정 배경 위에서 버튼 기본 스타일이 노출되지 않도록 명시적으로 초기화해야 합니다.

슬롯 구성:
```
left:  ∨ (chevron-down) 아이콘 1개 — 탭 시 미니 플레이어로 전환
right: 공유 아이콘 1개
```

---

## 페이지 레이아웃

콘텐츠 타입에 따라 미디어 영역이 달라집니다.

### 오디오 타입
```
topbar_player         ← TopBar Player 변형 (navigation.md 참조)
media_carousel        ← 이미지 카드 슬라이더 (carousel.md 참조)
content_block         ← 제목 + 부제목
action_buttons_ghost  ← Button.ghost (button.md 참조)
audio_player          ← 프로그레스바 + 컨트롤
segmented_control     ← SegmentedControl (tab.md 참조)
```

### 영상 타입
```
topbar_player         ← TopBar Player 변형 (navigation.md 참조)
video_player          ← 풀와이드 영상 영역 (carousel 대체)
content_block         ← 제목 + 부제목
action_buttons_ghost  ← Button.ghost (button.md 참조)
audio_player          ← 프로그레스바 + 컨트롤
segmented_control     ← SegmentedControl (tab.md 참조)
```

---

## VideoPlayer
> 영상 타입 전용. 오디오 타입에서는 MediaCarousel을 사용합니다.

```
layout:          풀와이드 (좌우 여백 없음, 화면 끝까지)
container_size:  width 100% / height width × 0.84 (1:0.84 비율 고정)
bg:              #000000
video:           16:9 비율로 컨테이너 중앙 배치 — 상하 남는 영역은 #000000 레터박스 처리
```

자막 오버레이:
```
position: 영상 하단 가운데
font:     body (15px / weight 400)
color:    color/player/text/strong (#FFFFFF)
```

전체화면 버튼:
```
position: 영상 우하단 오버레이
size:     36x36px
bg:       rgba(255,255,255,0.20)
icon:     24px / #FFFFFF
radius:   radius/sm (8px)
```

---

## MediaCarousel
> 상세 스펙은 `carousel.md` 참조. 여기서는 Player 전용 추가 요소만 기술.

```
콘텐츠 타입:       오디오일 때만 사용. 영상 콘텐츠일 때 MediaCarousel 사용 금지.
type:              type-peek (고정)
card_aspect_ratio: ratio-1-1 (고정 — 이미지 전용)
```

전체화면 버튼 (Player 전용):
```
position: 카드 우하단 오버레이
size: 36x36px
bg: rgba(255,255,255,0.20)
icon: 24px / #FFFFFF
radius: radius/sm (8px)
```

---

## ContentBlock

```
padding: spacing/xl (20px) 좌우 / spacing/md (12px) 상하
```

| 요소 | 폰트 | 색상 |
|------|------|------|
| 제목 | h2 (24px / weight 700) | color/player/text/strong (#FFFFFF) |
| 부제목 | body (15px / weight 400) | color/player/text/subtle (#8A8A8A) |

```
제목: 최대 2줄 / 말줄임 (...)
부제목: 제목 아래 spacing/xs (4px)
```

---

## AudioPlayer

```
padding: spacing/xl (20px) 좌우
```

### ProgressBar

```
track_height: 4px
track_bg: rgba(255,255,255,0.20)   ← 토큰 없음, 컴포넌트 직접 지정
fill_bg: color/player/text/strong (#FFFFFF)
thumb_size: 12px
thumb_bg: color/player/text/strong (#FFFFFF)
```

시간 텍스트:
```
font: caption (13px / weight 400)
color: color/player/text/subtle (#8A8A8A)
layout: 현재시간 왼쪽 / 전체시간 오른쪽
margin_top: spacing/xs (4px)
```

### Controls

```
layout: 5개 버튼 가로 균등 배치
margin_top: spacing/lg (16px)
```

| 버튼 | 아이콘 | 크기 | 색상 |
|------|--------|------|------|
| 속도 (x1.0) | 텍스트+아이콘 | 44x44px | color/player/icon/subtle |
| -5초 | 뒤로감기 | 44x44px | color/player/icon/default |
| 재생/일시정지 | play / pause | 56x56px | play_bg #FFFFFF / play_icon #000000 |
| +5초 | 앞으로감기 | 44x44px | color/player/icon/default |
| 자동 | 아이콘 | 44x44px | color/player/icon/subtle |

재생버튼:
```
shape: circle
bg: color/player/control/play_bg (#FFFFFF)
icon_color: color/player/control/play_icon (#000000)
icon_size: 28px
```

---

## SegmentedControl
> 상세 스펙은 `tab.md` 참조. 여기서는 Player 배치 규칙만 기술.

```
position: fixed bottom 0
outer_padding: spacing/md (12px) 상하 / spacing/xl (20px) 좌우
safe_area: padding-bottom env(safe-area-inset-bottom) — 생략 금지
bg_behind: color/player/background/page (#000000)
```

아이콘 매핑:
```
목차보기 → list 계열 아이콘
지도보기 → map 계열 아이콘
```

### SegmentedControl 탭 선택 시 동작

탭을 선택하면 두 가지가 동시에 발생합니다.

1. **BottomSheet 노출** — 선택한 탭의 콘텐츠(목차 또는 지도)를 BottomSheet로 표시. 스펙은 `bottomsheet.md` 참조.
   단, Player 전용 예외:
   - backdrop(dim) 없음 — 일반 BottomSheet의 `backdrop: rgba(0,0,0,0.50)` 적용 금지.
   - 시트 높이: MiniPlayer 하단부터 디바이스 하단까지 전체 차지 — `height: calc(100dvh - 120px)` (TopBar 56px + MiniPlayer 64px)
   - max-height: 80vh 제한 미적용.
2. **MiniPlayer 전환** — Player 본체가 화면 상단 MiniPlayer로 축소.

### 지도보기 시트 콘텐츠

지도 영역 하단에 **Player 카드형 리스트만** 사용합니다.

```
리스트형(순서 있는 투어) 사용 금지 — 카드형 단독 적용
```

---

### 목차보기 시트 콘텐츠 — 2가지 타입

> ⚠️ Player 전용 컴포넌트. `list.md`의 List.default / List.purchased 사용 금지.
> 재생 상태(active), 배지 오버레이, 하트 아이콘 등 Player 전용 요소가 포함되어 있어 일반 List와 구조가 다릅니다.

투어 성격에 따라 리스트 형태가 다릅니다.

#### 순서 있는 투어 → 리스트형

```
레이아웃: 썸네일(80px) 왼쪽 고정 / 텍스트 오른쪽 / 하트 아이콘 우측 끝
padding: 15px 상하 / 20px 좌우
gap: 12px (썸네일-텍스트)
썸네일 radius: radius/sm (8px) / 비율 1:1
아이템 사이: Divider (1px / #F0F0F0)
```

| 요소 | 스펙 |
|------|------|
| 제목 | 16px / weight 400 / #1A1A1A / 최대 3줄 말줄임 / 재생 중: #FF730D |
| English Name | 13px / weight 400 / #8A8A8A |
| Sub Name | 13px / weight 400 / #8A8A8A |
| 하트 아이콘 | 24px / #8A8A8A / 터치타겟 44×44px |

썸네일 오버레이 배지:
```
공사중: 텍스트 배지 / 썸네일 좌상단
잠금: lock 아이콘 / 썸네일 우상단
재생 중(active): 바 차트 아이콘 / 썸네일 중앙 하단 / 텍스트 색상 #FF730D로 함께 변경
```

#### 순서 없는 투어 → 카드형

```
레이아웃: 3열 그리드 / 세로 누적
columns: 3 (고정)
카드 너비: 자동 (컨테이너 ÷ 3 — gap 포함)
비율: 1:1 이미지 + 하단 텍스트 영역
카드 radius: radius/md (12px)
gap: spacing/sm (8px)
padding: spacing/xl (20px) 좌우
```

| 요소 | 스펙 |
|------|------|
| 제목 | 13px / weight 400 / #1A1A1A / 최대 2줄 말줄임 |
| 하트 아이콘 | 이미지 우하단 오버레이 / 24px / #FFFFFF |

이미지 오버레이 배지:
```
공사중: 텍스트 배지 / 이미지 좌상단
잠금: lock 아이콘 배지 / 이미지 우상단
재생 중(active): 바 차트 아이콘 / 이미지 좌상단 (공사중 배지 대체)
```

#### 아이템 상태 케이스 (리스트형 · 카드형 공통)

| 상태 | 조건 | 썸네일 오버레이 | 제목 색상 |
|------|------|----------------|-----------|
| 구매전(잠김) | 미구매 트랙 | lock 아이콘 (우상단) + 썸네일 dim `rgba(0,0,0,0.45)` | #1A1A1A |
| 재생가능 | 구매 완료 또는 무료 트랙 | 없음 | #1A1A1A |
| 공사중 | 재생가능 또는 구매전 상태에서 콘텐츠 준비 중 | 공사중 배지 (좌상단) | #1A1A1A |
| 미전시 | 재생가능 또는 구매전 상태에서 비공개 처리 | 미전시 배지 (좌상단) | #1A1A1A |
| 재생 중 | 현재 재생 중인 트랙 | 바 차트 아이콘 (중앙 하단 / 리스트형, 좌상단 / 카드형) | #FF730D |

> 공사중·미전시 배지는 재생가능·구매전 두 상태 모두에 중첩 적용될 수 있습니다.
> 재생 중 상태는 공사중·미전시 배지보다 우선하여 바 차트 아이콘으로 대체합니다.

셀프 체크:
```
□ 구매전 트랙에 lock 아이콘(우상단)이 표시되는가?
□ 구매전 트랙 썸네일에 dim(rgba(0,0,0,0.45))이 적용되는가?
□ 재생가능 트랙에 오버레이 배지가 없는가?
□ 공사중/미전시 배지가 좌상단에 표시되는가?
□ 재생 중 트랙의 제목 색상이 #FF730D인가?
□ 재생 중 상태에서 공사중/미전시 배지가 바 차트로 대체되는가?
```

---

## MiniPlayer

SegmentedControl 탭 선택 시 Player 본체를 대체하는 축소 형태.

```
position: fixed top 0  (TopBar 바로 아래)
width: 100%
height: 64px
bg: color/player/background/page (#000000)
padding: 0 spacing/xl (20px) 좌우
layout: 썸네일 — 제목/부제목 — 재생/일시정지 버튼 (가로 배치)
```

| 요소 | 스펙 |
|------|------|
| 썸네일 | 44×44px / radius/sm (8px) / 오브젝트핏 cover |
| 제목 | body (15px / weight 600) / color/player/text/strong / 1줄 말줄임 |
| 부제목 | caption (13px / weight 400) / color/player/text/subtle / 1줄 말줄임 |
| 재생버튼 | 44×44px 터치타겟 / 아이콘 24px / color/player/icon/default |

```
썸네일 — 텍스트 영역 gap: spacing/md (12px)
텍스트 영역: flex 1 (남은 공간 모두 차지)
MiniPlayer 탭 시: BottomSheet 닫힘 + Player 본체로 복귀
```

---

## ❌ 절대 하지 말 것

```
- 영상 콘텐츠 타입에서 MediaCarousel 사용 금지 (오디오 전용)
- MediaCarousel에 type-slide 사용 금지 (type-peek 고정)
- color/player/* 토큰을 Player 화면 외에서 사용 금지
- Player 화면에서 일반 color/* 토큰 사용 금지 (player 네임스페이스로 교체)
- ProgressBar track에 토큰 없는 rgba 외 임의 색상 사용 금지
- ghost 버튼 외 다른 Button variant를 action_buttons에 사용 금지
- SegmentedControl을 Player 외 화면에 사용 금지
- safe-area 생략 금지
- 시트가 열린 상태에서 추가 시트 열기 금지 — 시트는 한 번에 하나만 허용
- 목차 리스트에 list.md의 List 컴포넌트 사용 금지 — Player 전용 스펙으로만 구현
```

---

## 셀프 체크

```
□ 배경이 #000000인가?
□ 텍스트/아이콘이 player 토큰을 참조하는가?
□ TopBar가 Player 변형(검정 배경, 흰 아이콘)인가?
□ action_buttons가 Button.ghost인가?
□ ProgressBar track이 rgba(255,255,255,0.20)인가?
□ 재생버튼이 흰 배경 + 검정 아이콘인가?
□ SegmentedControl safe-area가 적용되었는가?
□ SegmentedControl 선택지가 균등 분할인가?
```
