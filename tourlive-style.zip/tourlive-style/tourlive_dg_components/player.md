# Player 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.SegmentedControl`, `color.player.*`
> Player 화면은 전용 컬러 팔레트(`color.player.*`)를 사용합니다. 일반 색상 토큰 사용 금지.

---

## Player 화면 컬러 원칙

```
배경              color/player/background/page  (#000000)
주요 텍스트       color/player/text/strong      (#FFFFFF)
보조 텍스트       color/player/text/subtle      (#8A8A8A)
기본 아이콘       color/player/icon/default     (#FFFFFF)
보조 아이콘       color/player/icon/subtle      (#8A8A8A)
재생버튼 배경     color/player/control/play_bg  (#FFFFFF)
재생버튼 아이콘   color/player/control/play_icon (#000000)
```

---

## 페이지 레이아웃

콘텐츠 타입에 따라 미디어 영역이 달라집니다.

### 오디오 타입
```
topbar_player         ← TopBar Player 변형 (navigation.md 참조)
media_carousel        ← 이미지 카드 슬라이더 (carousel.md 참조)
content_block         ← 제목 + 부제목
action_buttons_ghost  ← Button.ghost (button.md 참조)
audio_player          ← 프로그레스바 + 컨트롤
segmented_control     ← SegmentedControl (tab.md 참조)
```

### 영상 타입
```
topbar_player         ← TopBar Player 변형 (navigation.md 참조)
video_player          ← 풀와이드 영상 영역 (carousel 대체)
content_block         ← 제목 + 부제목
action_buttons_ghost  ← Button.ghost (button.md 참조)
audio_player          ← 프로그레스바 + 컨트롤
segmented_control     ← SegmentedControl (tab.md 참조)
```

---

## VideoPlayer
> 영상 타입 전용. 오디오 타입에서는 MediaCarousel을 사용합니다.

```
layout:          풀와이드 (좌우 여백 없음, 화면 끝까지)
container_size:  width 100% / height width × 0.84 (1:0.84 비율 고정)
bg:              #000000
video:           16:9 비율로 컨테이너 중앙 배치 — 상하 남는 영역은 #000000 레터박스 처리
```

자막 오버레이:
```
position: 영상 하단 가운데
font:     body (15px / weight 400)
color:    color/player/text/strong (#FFFFFF)
```

전체화면 버튼:
```
position: 영상 우하단 오버레이
size:     36x36px
bg:       rgba(255,255,255,0.20)
icon:     24px / #FFFFFF
radius:   radius/sm (8px)
```

---

## MediaCarousel
> 상세 스펙은 `carousel.md` 참조. 여기서는 Player 전용 추가 요소만 기술.

```
콘텐츠 타입:       오디오일 때만 사용. 영상 콘텐츠일 때 MediaCarousel 사용 금지.
type:              type-peek (고정)
card_aspect_ratio: ratio-1-1 (고정 — 이미지 전용)
```

전체화면 버튼 (Player 전용):
```
position: 카드 우하단 오버레이
size: 36x36px
bg: rgba(255,255,255,0.20)
icon: 24px / #FFFFFF
radius: radius/sm (8px)
```

---

## ContentBlock

```
padding: spacing/xl (20px) 좌우 / spacing/md (12px) 상하
```

| 요소 | 폰트 | 색상 |
|------|------|------|
| 제목 | h2 (24px / weight 700) | color/player/text/strong (#FFFFFF) |
| 부제목 | body (15px / weight 400) | color/player/text/subtle (#8A8A8A) |

```
제목: 최대 2줄 / 말줄임 (...)
부제목: 제목 아래 spacing/xs (4px)
```

---

## AudioPlayer

```
padding: spacing/xl (20px) 좌우
```

### ProgressBar

```
track_height: 4px
track_bg: rgba(255,255,255,0.20)   ← 토큰 없음, 컴포넌트 직접 지정
fill_bg: color/player/text/strong (#FFFFFF)
thumb_size: 12px
thumb_bg: color/player/text/strong (#FFFFFF)
```

시간 텍스트:
```
font: caption (13px / weight 400)
color: color/player/text/subtle (#8A8A8A)
layout: 현재시간 왼쪽 / 전체시간 오른쪽
margin_top: spacing/xs (4px)
```

### Controls

```
layout: 5개 버튼 가로 균등 배치
margin_top: spacing/lg (16px)
```

| 버튼 | 아이콘 | 크기 | 색상 |
|------|--------|------|------|
| 속도 (x1.0) | 텍스트+아이콘 | 44x44px | color/player/icon/subtle |
| -5초 | 뒤로감기 | 44x44px | color/player/icon/default |
| 재생/일시정지 | play / pause | 56x56px | play_bg #FFFFFF / play_icon #000000 |
| +5초 | 앞으로감기 | 44x44px | color/player/icon/default |
| 자동 | 아이콘 | 44x44px | color/player/icon/subtle |

재생버튼:
```
shape: circle
bg: color/player/control/play_bg (#FFFFFF)
icon_color: color/player/control/play_icon (#000000)
icon_size: 28px
```

---

## SegmentedControl
> 상세 스펙은 `tab.md` 참조. 여기서는 Player 배치 규칙만 기술.

```
position: fixed bottom 0
outer_padding: spacing/md (12px) 상하 / spacing/xl (20px) 좌우
safe_area: padding-bottom env(safe-area-inset-bottom) — 생략 금지
bg_behind: color/player/background/page (#000000)
```

아이콘 매핑:
```
목차보기 → list 계열 아이콘
지도보기 → map 계열 아이콘
```

---

## ❌ 절대 하지 말 것

```
- 영상 콘텐츠 타입에서 MediaCarousel 사용 금지 (오디오 전용)
- MediaCarousel에 type-slide 사용 금지 (type-peek 고정)
- color/player/* 토큰을 Player 화면 외에서 사용 금지
- Player 화면에서 일반 color/* 토큰 사용 금지 (player 네임스페이스로 교체)
- ProgressBar track에 토큰 없는 rgba 외 임의 색상 사용 금지
- ghost 버튼 외 다른 Button variant를 action_buttons에 사용 금지
- SegmentedControl을 Player 외 화면에 사용 금지
- safe-area 생략 금지
```

---

## 셀프 체크

```
□ 배경이 #000000인가?
□ 텍스트/아이콘이 player 토큰을 참조하는가?
□ TopBar가 Player 변형(검정 배경, 흰 아이콘)인가?
□ action_buttons가 Button.ghost인가?
□ ProgressBar track이 rgba(255,255,255,0.20)인가?
□ 재생버튼이 흰 배경 + 검정 아이콘인가?
□ SegmentedControl safe-area가 적용되었는가?
□ SegmentedControl 선택지가 균등 분할인가?
```
