# Toast 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.Toast`
> 단순 피드백·알림 전용. 중요 정보는 Modal 사용. 자동 소멸.

---

## 스펙

```
bg: #3A3A3A / opacity 0.8
radius: 12px (radius/md)
padding: 14px 16px
max_width: 335px
position: 하단 고정 / BottomTab 위 20px
duration: 3000ms (자동 소멸)
animation: 250ms fade (등장/소멸)
text: 15px / weight 400 / #FFFFFF / 최대 2줄 말줄임
```

---

## Variant 선택 기준

| 상황 | Variant |
|------|---------|
| 텍스트 안내만 | `default` |
| 사용자가 직접 닫아야 할 때 | `closable` |
| 동작이 필요한 안내 (실행취소 등) | `actionable` |

---

## Variant별 스펙

### default
```
close_button: 없음
action_button: 없음
자동 소멸: 3000ms
```

### closable
```
close_button: × 20px / #FFFFFF
action_button: 없음
자동 소멸: 없음 (사용자가 닫아야 함)
```

### actionable
```
close_button: 없음
action_button: 15px / weight 700 / #FF730D
자동 소멸: 3000ms
```

---

## ❌ 절대 하지 말 것

```
- 중요 정보·필수 확인 내용 Toast에 담기 금지 → Modal 사용
- closable 외에 자동 소멸 제거 금지
- close_button과 action_button 동시 사용 금지
- 버튼 2개 이상 금지
```

---

## 셀프 체크

```
□ bg가 #3A3A3A opacity 0.8인가?
□ 3000ms 자동 소멸이 구현되었는가? (closable 제외)
□ close_button과 action_button이 동시에 없는가?
□ 중요 정보가 Toast에 담기지 않았는가?
```
