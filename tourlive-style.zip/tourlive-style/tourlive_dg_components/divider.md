# Divider 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.Divider`
> 섹션 구분선. 색상·두께 외 임의 스타일 추가 금지.

---

## Variant

| Variant | height | color | 사용처 |
|---------|--------|-------|--------|
| `default` | 1px | #D1D1D1 | 일반 콘텐츠 사이 구분 |
| `thick` | 8px | #F2F4F7 | 페이지 내 큰 섹션 구분 (투어 상세, 마이페이지 등) |

---

## ❌ 절대 하지 말 것

```
- 임의 두께 사용 금지 — default(1px) / thick(8px)만 허용
- 색상 임의 변경 금지
- margin을 컴포넌트 내부에 포함 금지 — 외부 spacing으로 제어
```

---

## 셀프 체크

```
□ thick이 8px인가? (16px, 10px 등 임의 두께 금지)
□ default color가 #D1D1D1인가?
□ thick color가 #F2F4F7인가?
□ margin이 컴포넌트 외부에서 제어되고 있는가?
```
