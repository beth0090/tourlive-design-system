# Badge 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.Badge`
> 상태·속성 표시용 라벨. 클릭 불가 요소. 버튼 대신 사용 금지.

---

## Variant 선택 기준

| 상황 | Variant |
|------|---------|
| 카드 내 무료트랙 수, 업데이트 등 인라인 표기 | `text` |
| 필터 칩, 선택 상태 표시 | `outlined` |
| 강조 라벨, 상태 태그 | `filled` |

---

## 공통 스펙

```
font: 11px / weight 600 / letterSpacing 0.04em
radius: 9999px (radius/full)
icon: 12px / 텍스트 왼쪽 / gap 4px — hasIcon: true일 때만 렌더
```

---

## Variant별 스펙

### text
padding·border 없음. bg transparent.

| Color | text |
|-------|------|
| orange | #FF730D |
| red | #FA3E4D |
| green | #19B800 |

※ text variant에 default color 사용 금지

### outlined
padding: `3px 8px` / border: `1px solid`

| Color | border | text |
|-------|--------|------|
| default | #D1D1D1 | #1A1A1A |
| orange | #FF730D | #FF730D |
| red | #FA3E4D | #FA3E4D |
| green | #19B800 | #19B800 |

### filled
height: `18px` (`size/18`) / padding: `3px 8px` / border 없음 / radius: `2px` (공통 radius/full 예외)

| Color | bg | text |
|-------|-----|------|
| default | #F2F4F7 | #1A1A1A |
| orange | #FFF3EC | #FF730D |
| red | #FFF0F0 | #FA3E4D |
| green | #E8FFF3 | #19B800 |

---

## ❌ 절대 하지 말 것

```
- 버튼 대신 Badge 사용 금지 (클릭 이벤트 부여 금지)
- 4가지 color(default/orange/red/green) 외 임의 색상 금지
- filled에 border 추가 금지
- filled radius를 2px 외 다른 값으로 변경 금지
- text variant에 padding/border 추가 금지
- text variant에 default color 사용 금지
- hasIcon 없이 아이콘 렌더 금지
```

---

## 셀프 체크

```
□ variant가 text/outlined/filled 중 하나인가?
□ color가 default/orange/red/green 중 하나인가?
□ text variant에 padding/border가 없는가?
□ filled radius가 2px인가?
□ filled에 border가 없는가?
□ text variant에 default color를 쓰지 않는가?
□ hasIcon=false일 때 아이콘 영역이 없는가?
□ 클릭 이벤트가 없는가?
```
