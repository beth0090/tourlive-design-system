# List / Skeleton 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `components.List`, `components.Skeleton`
> 투어 목록 표시 전용. 세로형은 커스텀 — 스펙 미정의, 임의 구현 금지.

---

## List.default

검색 결과, 투어 목록 표준 리스트.

```
레이아웃: 썸네일(108px) 왼쪽 고정 / 텍스트 오른쪽
padding: 15px 상하 / 20px 좌우
gap: 15px (썸네일-텍스트)
썸네일 radius: 8px (radius/sm) / 비율 1:1
아이템 사이: Divider.default (1px / #D1D1D1)
```

### 콘텐츠 구조 (위→아래)

| 요소 | 스펙 |
|------|------|
| badges | Badge.text — 업데이트·무료N개 |
| title | 16px / weight 400 / #1A1A1A / 최대 2줄 말줄임 |
| price | 아래 price 규칙 참조 |
| meta | 13px / #8A8A8A / 별점 · 미디어타입 · 재생시간 |

### priceType별 price 표시

**sale** (할인 있음)
```
원가: 14px / weight 400 / #8A8A8A / line-through
할인가 prefix: "할인가" 텍스트
할인가: 16px / weight 700 / #1A1A1A
```

**single** (할인 없음)
```
가격: 16px / weight 700 / #1A1A1A
```

**purchased** (구매 완료)
```
"구매완료" 텍스트: 14px / weight 400 / #8A8A8A
```

---

## List.purchased

구매한 투어 목록. 다운로드 상태 관리.

```
레이아웃: 텍스트 왼쪽 / 썸네일(96px) 오른쪽 고정
padding: 15px 상하 / 20px 좌우
gap: 15px (텍스트-썸네일)
썸네일 radius: 8px / 비율 1:1
아이템 사이: Divider.default
```

### action_button (썸네일 위 오버레이)

```
position: 썸네일 위 전체 오버레이
bg: rgba(0,0,0,0.45)
icon: 20px / #FFFFFF
label: 13px / weight 400 / #FFFFFF
```

### 상태 7종

| State | action | meta 색상 | 비고 |
|-------|--------|-----------|------|
| ready | 다운로드 아이콘 + "다운로드" | #8A8A8A | |
| downloading | 중지 아이콘 + "중지" | #8A8A8A | |
| done | play-circle (#FF730D) | #8A8A8A | 오버레이 bg 없음 |
| failed | 다운로드 아이콘 + "다운로드" | #FA3E4D | |
| expired | 없음 | #FA3E4D | 썸네일·텍스트 opacity 0.4 |
| exceeded | 없음 | #FA3E4D | 썸네일·텍스트 opacity 0.4 |
| timeout | play-circle (#FF730D) | #FA3E4D | 재생 가능 |

---

## Skeleton

List 로딩 상태 전용. List 외 컴포넌트에 사용 금지.

```
animation: shimmer / 좌→우 / 1500ms linear infinite
base: #F2F4F7
shimmer: #FFFFFF opacity 0.4
block radius: 8px
```

### Skeleton.list_default

```
썸네일: 108x108px / radius 8px
badge_line: 60px x 11px
title_line_1: 100% x 16px
title_line_2: 70% x 16px
price_line: 80px x 16px
meta_line: 120px x 13px
gap: 15px (썸네일-콘텐츠)
```

### Skeleton.list_purchased

```
레이아웃: 콘텐츠 왼쪽 / 썸네일 오른쪽
썸네일: 96x96px / radius 8px
title_line_1: 100% x 16px
title_line_2: 60% x 16px
meta_line: 80px x 13px
gap: 15px (콘텐츠-썸네일)
```

---

## ❌ 절대 하지 말 것

```
- 세로형 List 임의 구현 금지
- 썸네일 radius 임의 변경 금지 — 반드시 8px
- 아이템 사이 Divider.default 생략 금지
- purchased 레이아웃에서 썸네일 왼쪽 배치 금지
- List 외 컴포넌트에 Skeleton 적용 금지
- shimmer 외 애니메이션 방식 사용 금지
```

---

## 셀프 체크

```
□ List.default 썸네일이 108px 왼쪽인가?
□ List.purchased 썸네일이 96px 오른쪽인가?
□ action_button이 썸네일 위 오버레이인가?
□ 아이템 사이 Divider.default가 있는가?
□ 상태별 meta_color가 올바른가?
□ expired/exceeded 상태에서 opacity 0.4가 적용되었는가?
□ Skeleton shimmer 애니메이션(좌→우, 1500ms)이 구현되었는가?
□ Skeleton 레이아웃이 실제 List 구조와 동일한가?
```
