# Carousel 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `spacing.*`, `radius.*`, `components.DotNavigation`, `components.CountNavigation`
> Carousel은 배경을 갖지 않습니다. 배경색은 부모 페이지를 따릅니다.

---

## Carousel 타입

### type-peek (기본형)

```
[이전 카드 일부] [현재 카드 (중앙)] [다음 카드 일부]
         ● ● ○ ○  ← DotNavigation 또는 CountNavigation (카드 하단 가운데)
```

```
card_radius: radius/md (12px)
peek_width:  20px (좌우 각각)
gap:         spacing/sm (8px)
```

네비게이션 (카드 영역 침범 금지):
```
position:    카드 하단 가운데 (카드 아래 별도 영역)
type:        DotNavigation 또는 CountNavigation 중 하나 선택 (사용처에서 결정)
margin_top:  spacing/sm (8px)
```

### type-slide (전체 너비형)

```
[ <  현재숫자/전체숫자 ↗    현재 카드 (전체 너비)   > ]
  ↑ 이전버튼                 CountNavigation (우상단)  ↑ 다음버튼
```

```
card_radius: 0 (radius 없음 — 화면 끝까지 꽉 채움)
peek_width:  0 (없음)
gap:         0 (없음)
```

CountNavigation:
```
type:     CountNavigation (카드 내 우상단 오버레이, DotNavigation 사용 금지)
position: 카드 우상단
```

이전/다음 버튼:
```
position:    카드 좌우 끝 세로 가운데 오버레이
touch_target: 36x36px (터치 영역만 — 컨테이너 박스 렌더링 금지)
icon:        < / > (chevron), 20px / #FFFFFF
icon_shadow: drop-shadow(0px 1px 4px rgba(0,0,0,0.50)) — 아이콘에만 적용
첫 번째 카드: 이전 버튼 숨김
마지막 카드:  다음 버튼 숨김
```
> ❌ 버튼 컨테이너에 background / border / box-shadow 지정 금지. 그림자는 아이콘 자체에만 적용.

> 카드가 화면 좌우 끝에 붙으므로 카드 자체에 padding이나 radius를 지정하지 않습니다.

---

## 네비게이션 스펙

> 스펙 상세는 `tourlive_dg_tokens.json` → `components.DotNavigation` / `components.CountNavigation` 참조.
> 여기서는 Carousel 내 배치 규칙만 기술합니다.

### DotNavigation (type-peek 전용)
```
position: 카드 하단 가운데 (카드 외부 별도 영역)
margin_top: spacing/sm (8px)
```

### CountNavigation
```
type-peek:  카드 하단 가운데 (카드 외부 별도 영역) / margin_top: spacing/sm (8px)
type-slide: 카드 내 우상단 오버레이
```

---

## card_aspect_ratio (필수 지정)

| variant | 비율 | 사용 조건 |
|---------|------|----------|
| `ratio-16-9` | 16:9 | 영상 콘텐츠를 포함할 때. 투어 상세 페이지 미디어 슬라이더에 사용. |
| `ratio-1-1`  | 1:1  | 이미지만 사용할 때. 영상 콘텐츠를 담는 경우 권장하지 않음. |

> 비율을 지정하지 않으면 카드 높이가 콘텐츠에 따라 달라져 레이아웃이 깨집니다. 반드시 둘 중 하나를 명시하세요.

---

## 사용 시 주의

```
- 카드 콘텐츠(이미지, 영상 썸네일 등)는 사용처에서 정의합니다.
- 전체화면 버튼 등 오버레이 추가 요소는 사용처 컴포넌트에서 별도 기술합니다.
- peek 영역의 카드는 dimmed 처리 없이 그대로 노출합니다.
- type-slide에 DotNavigation 추가 금지. CountNavigation만 허용 (카드 내 우상단 오버레이).
```

---

## 사용 예시

| 화면 | 타입 | 비율 | 참조 |
|------|------|------|------|
| Player 미디어 슬라이더 | type-peek | ratio-1-1 | `player.md` → MediaCarousel |

---

## 셀프 체크

```
□ type-peek 또는 type-slide 중 하나로 타입이 명시되어 있는가?
□ card_aspect_ratio가 ratio-16-9 또는 ratio-1-1 중 하나로 명시되어 있는가?
□ type-peek 사용 시 네비게이션이 카드 하단 가운데에 배치되어 있는가? (카드 영역 침범 금지)
□ type-slide 사용 시 CountNavigation이 카드 내 우상단 오버레이로 배치되어 있는가?
□ type-slide 사용 시 이전/다음 버튼이 카드 좌우 세로 가운데에 있는가?
□ type-slide 사용 시 첫/마지막 카드에서 해당 방향 버튼이 숨겨지는가?
□ type-slide 사용 시 DotNavigation을 추가하지 않았는가?
□ type-slide 사용 시 카드에 radius나 padding을 지정하지 않았는가?
□ Carousel 자체에 배경색을 지정하지 않았는가?
```
