# Accordion 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `tokens.color`, `tokens.motion`, `tokens.radius`
> FAQ, 투어 상세 설명 등 접고 펼치는 콘텐츠에 사용. 항상 열려있어야 하는 콘텐츠는 사용 금지.

---

## 스펙

```
bg: #FFFFFF
border-bottom: 1px solid #D1D1D1 (border.default)
radius: 없음
animation: height expand / 250ms cubic-bezier(0.4,0,0.2,1) (motion.normal)
```

---

## Header

```
padding: 16px 0 (spacing.lg 상하만 / 좌우 없음)
layout: 제목 왼쪽 / 아이콘 오른쪽 고정
min-height: 52px
```

| 요소 | 스펙 |
|------|------|
| title | 16px / weight 400 / color.text.strong (#1A1A1A) |
| icon | + (collapsed) / - (expanded) / 24px / color.primary.default (#FF730D) |

---

## 상태

| 상태 | header bg | title color | 비고 |
|------|-----------|-------------|------|
| collapsed | #FFFFFF | #1A1A1A | content 숨김 |
| expanded | #FFFFFF | #1A1A1A | content 표시 |

> ⚠️ disabled 상태 미제공 — 비활성 처리가 필요한 경우 해당 아이템 자체를 렌더링하지 않는다.

---

## Content

```
padding: 0 0 16px (하단 spacing.lg만 / 좌우 없음)
bg: color.background.page (#FFFFFF)
font: 14px / weight 400 / color.text.default (#3A3A3A) / line-height 1.6
```

---

## 동작 규칙

- 각 항목은 독립적으로 작동 — 다른 항목 상태에 영향 없음
- 애니메이션은 height: 0 → auto (overflow: hidden)으로 구현

---

## ❌ 절대 하지 말 것

```
- 항상 열려있어야 할 콘텐츠에 사용 금지
- 애니메이션 없이 즉시 show/hide 처리 금지
- +/- 외 임의 아이콘 사용 금지
- content padding 생략 금지
- disabled 상태 구현 금지 — 노출하지 않을 아이템은 렌더링 자체를 생략
- 다른 항목 클릭 시 열린 항목 자동으로 닫는 방식 사용 금지 (각 항목 독립 동작)
```

---

## 셀프 체크

```
□ header padding이 상하(16px)만 적용되었는가? (좌우 없음)
□ collapsed 상태에서 + 아이콘인가?
□ expanded 상태에서 - 아이콘인가?
□ 아이콘 색상이 color.primary.default (#FF730D)인가?
□ height expand 애니메이션이 250ms motion.normal인가?
□ disabled 아이템이 렌더링 없이 생략되었는가?
□ 각 항목이 다른 항목과 독립적으로 동작하는가?
□ content에 overflow: hidden이 적용되어 있는가?
```
