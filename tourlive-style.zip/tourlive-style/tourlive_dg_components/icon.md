# Icon 컴포넌트
> 참조: `tourlive_dg_tokens.json` → `tokens.color`, `tokens.spacing`
> TourLive는 **Google Material Icons**을 표준 아이콘 라이브러리로 사용합니다.
> 이모지 및 Google Material Icons 외 외부 아이콘 라이브러리(Feather, Font Awesome 등) 사용 금지.

---

## 라이브러리 사용법

Google Material Symbols를 사용합니다. (구 Material Icons 아님)

### 스타일 기본값 (변경 불가)

| 항목 | 값 | 비고 |
|------|----|------|
| Style | **Rounded** | Outlined·Filled·Sharp·Two tone 사용 금지 |
| Weight | **400** | 100~700 중 400만 허용 |
| Grade | 0 | 기본값 유지 |
| Optical size | 24 | 기본값 유지 |

```
❌ Filled 스타일 사용 금지 (fill=1 금지)
❌ Weight 400 외 값 사용 금지
✅ 항상 Rounded + Weight 400 조합으로 고정
```

### 방법 1 — Google Fonts CDN (웹)
```html
<!-- Material Symbols Rounded, Weight 400 고정 -->
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" rel="stylesheet">
<span class="material-symbols-rounded" aria-hidden="true">search</span>
```

```css
/* Weight·Fill 고정 CSS 변수 */
.material-symbols-rounded {
  font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
}
```

### 방법 2 — SVG 파일 직접 사용 (권장)
Google Material Symbols GitHub에서 Rounded 스타일 SVG를 다운로드하여 사용합니다.
```
https://github.com/google/material-design-icons
경로: symbols/web/{icon_name}/materialsymbolsrounded/{icon_name}_wght400_24px.svg
```
```xml
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="..." fill="currentColor"/>
</svg>
```

```
아이콘 이름·형태는 Google Material Symbols 기준으로 통일한다.
(예: 검색 → "search", 닫기 → "close", 뒤로가기 → "arrow_back")
```

---

## 크기 체계

| Size | px  | viewBox      | 사용 맥락 |
|------|-----|--------------|----------|
| xs   | 12px | 0 0 12 12   | Badge 내부 아이콘 |
| sm   | 16px | 0 0 16 16   | Button 내부 아이콘, Form 보조 아이콘 |
| md   | 20px | 0 0 20 20   | List 아이템 아이콘, 캐러셀 화살표 |
| lg   | 24px | 0 0 24 24   | TopBar 아이콘, BottomTab 아이콘, Player 컨트롤 |
| xl   | 32px | 0 0 32 32   | 플레이어 주요 컨트롤 (되감기/앞으로감기) |
| 2xl  | 48px | 0 0 48 48   | 빈 상태(Empty State) 일러스트 아이콘 |

```
아이콘 크기는 위 6단계 중 하나만 사용한다.
임의의 px 값(예: 18px, 22px) 사용 금지.
```

---

## 색상 규칙

아이콘 색상은 반드시 `tourlive_dg_tokens.json`의 color 토큰을 참조합니다.

| 토큰 경로 | hex | 사용 맥락 |
|-----------|-----|----------|
| `color/primary/default` | #FF730D | 하단 탭 활성 아이콘, CTA 영역 강조 아이콘 |
| `color/text/strong` | #1A1A1A | 기본 UI 아이콘 (TopBar, 일반 화면) |
| `color/text/subtle` | #8A8A8A | 비활성 탭 아이콘, 보조 아이콘 |
| `color/text/disabled` | #A0A0A0 | 비활성(disabled) 상태 아이콘 |
| `color/text/inverse` | #FFFFFF | 어두운 배경 위 아이콘 (filled 버튼 내부) |
| `color/feedback/error` | #FA3E4D | 삭제·오류 아이콘 |
| `color/feedback/success` | #4CAF50 | 완료·성공 아이콘 |
| `color/player/icon/default` | #FFFFFF | Player 화면 기본 아이콘 |
| `color/player/icon/subtle` | #8A8A8A | Player 화면 보조 아이콘 |
| `color/player/control/play_icon` | #000000 | 재생/일시정지 버튼 내부 아이콘 |

```
❌ 임의 hex로 아이콘 색상 지정 금지
❌ 컨텍스트에 맞지 않는 토큰 혼용 금지
   (예: Player 화면 밖에서 color/player/* 사용 금지)
```

---

## 터치 영역 (Touch Target)

```
아이콘 자체에 터치 영역을 지정하지 않는다.
44 × 44px 확보 책임은 아이콘을 감싸는 부모 컴포넌트(button, tab 등)에 있다.
→ 각 컴포넌트 스펙(button.md, navigation.md 등)의 터치 영역 규칙을 따른다.

장식용(인터랙션 없음) 아이콘은 터치 영역 불필요.
```

---

## 접근성 규칙

```
인터랙션 있는 아이콘
  → aria-label 필수: 동작을 명확히 기술 (예: "뒤로가기", "검색", "닫기")
  → role="button" 또는 <button> 태그 사용
  → focusable: true (키보드 접근 가능)

장식용 아이콘 (텍스트 옆 보조)
  → aria-hidden="true" 필수
  → focusable: false

상태 전달 아이콘 (예: 완료 체크, 오류 X)
  → aria-label로 상태 설명 (예: "완료됨", "오류 발생")
  → 색상만으로 상태를 전달하지 않음 (색맹 사용자 고려)
```

---

## SVG 파일 규칙

```
viewBox: 아이콘 크기에 맞는 값 사용 (위 크기 체계 참조)
fill: 코드에서 주입 (SVG 파일 내 color 하드코딩 금지)
stroke: 필요 시 코드에서 주입
currentColor: fill="currentColor" 사용 권장 → CSS color 상속 가능
불필요한 그룹·레이어 제거: 최소한의 path만 유지
아이콘 이름: Google Material Icons 명칭 기준으로 통일
```

```xml
<!-- 권장 SVG 구조 예시 (Google Material Icons 기반) -->
<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="..." fill="currentColor"/>
</svg>
```

---

## 컨텍스트별 조합 규칙

### TopBar 아이콘
```
크기: lg (24px)
색상: color/text/strong (#1A1A1A) — 일반 화면
      color/player/icon/default (#FFFFFF) — Player 화면
터치: 44×44px 컨테이너
좌우 슬롯 각 최대 2개, 아이콘 간 gap: 8px (spacing/sm)
```

### BottomTab 아이콘
```
크기: lg (24px)
색상: 활성 → color/primary/default (#FF730D)
      비활성 → color/text/subtle (#8A8A8A)
아이콘-텍스트 간격: 4px (spacing/xs)
```

### Button 내부 아이콘
```
크기: sm (16px)
위치: 텍스트 왼쪽
텍스트와 간격: 4px (spacing/xs)
색상: 버튼 variant 텍스트 색상과 동일하게 상속 (currentColor)
hasIcon: false일 때 아이콘 영역 렌더하지 않음
```

### Form 아이콘
```
검색 아이콘: sm (16px) / color/text/subtle (#8A8A8A) / 인풋 왼쪽
삭제(×) 아이콘: sm (16px) / color/text/subtle (#8A8A8A) / 인풋 오른쪽 / 텍스트 입력 시만 표시
```

### Player 컨트롤 아이콘
```
기본 컨트롤(재생·일시정지·앞으로·뒤로): xl (32px)
보조 컨트롤(속도·자동재생 등): lg (24px)
색상: color/player/icon/default (#FFFFFF) — 기본
      color/player/icon/subtle (#8A8A8A) — 보조
      color/player/control/play_icon (#000000) — 재생버튼 아이콘
```

---

## ❌ 절대 하지 말 것

```
- 이모지를 아이콘 대신 사용 금지
- Google Material Symbols 외 외부 라이브러리(Feather, Font Awesome 등) 사용 금지
- Filled 스타일(fill=1) 사용 금지
- Weight 400 외 값(100·200·300·500·700 등) 사용 금지
- Outlined·Sharp·Two tone 스타일 사용 금지
- 임의 px 크기(18px, 22px 등) 사용 금지
- SVG 파일 내 색상 하드코딩 금지 (currentColor 사용)
- 인터랙션 있는 아이콘에 aria-label 누락 금지
- 장식용 아이콘에 aria-hidden="true" 누락 금지
- 색상만으로 상태 전달 금지 (텍스트·아이콘 형태 병행 필수)
- 아이콘 자체에 min-width/min-height/padding으로 터치 영역 지정 금지 (부모 컴포넌트 책임)
- Player 컨텍스트 밖에서 color/player/* 토큰 사용 금지
```

---

## 셀프 체크

```
□ 아이콘 크기가 xs/sm/md/lg/xl/2xl 중 하나인가?
□ 색상이 tourlive_dg_tokens.json color 토큰을 참조하는가?
□ SVG에 fill="currentColor" 또는 코드 주입 방식을 사용하는가?
□ Google Material Symbols Rounded 스타일을 사용하는가? (Filled·Outlined·Sharp 금지)
□ Weight가 400으로 고정되어 있는가? (font-variation-settings 또는 SVG 파일명 확인)
□ 인터랙션 있는 아이콘에 aria-label이 있는가?
□ 장식용 아이콘에 aria-hidden="true"가 있는가?
□ 아이콘 자체에 터치 영역(min-width/min-height/padding)을 직접 지정하지 않았는가?
□ Player 아이콘이 Player 컨텍스트 내에서만 쓰이는가?
□ BottomTab 활성/비활성 색상이 올바른 토큰을 쓰는가?
```
